#ifndef PROJET_REPORT_H
#define PROJET_REPORT_H

#include <stdio.h>

#include <projet/sensor_source.h>

typedef struct {
    char *label;
} SensorReportOptions;

int sensor_report_options_init(SensorReportOptions *options, const char *label);
void sensor_report_options_clear(SensorReportOptions *options);
void sensor_report_print(FILE *output, const SensorDataset *dataset,
    const SensorReportOptions *options);
int sensor_report_write_csv(FILE *output, const SensorDataset *dataset,
    const SensorReportOptions *options);

#endif
